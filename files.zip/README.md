# MindMeld MCP Server v1.1.0 (Fixed)

This is the fixed version of the MindMeld MCP server that resolves the following bugs:

## Bugs Fixed

### 1. Open File Parse Error
**Issue:** `Cannot read properties of undefined (reading 'TEXT')`

**Root Cause:** fast-xml-parser uses `@_` prefix for XML attributes by default, but the code expected unprefixed attributes like `TEXT` instead of `@_TEXT`.

**Fix:** Configured fast-xml-parser with `attributeNamePrefix: ""` to remove the prefix, plus added a normalization function that handles any remaining prefixed attributes.

### 2. Markdown Export Broken  
**Issue:** Returns "undefined" for all node text

**Root Cause:** Same attribute naming mismatch as above.

**Fix:** Safe fallback when accessing TEXT property and proper attribute normalization.

### 3. Path Resolution Issue
**Issue:** Unix paths like `/home/claude/file.mm` were being converted to Windows paths like `C:\home\claude\file.mm`

**Fix:** Added `normalizePath()` function that properly handles paths for the current platform.

## Installation

### Option 1: Replace Existing Installation

1. Copy `index.js` to replace your existing MindMeld MCP server
2. Restart Claude Desktop

### Option 2: Fresh Installation

1. Create a directory for the server:
   ```bash
   mkdir mindmeld-mcp
   cd mindmeld-mcp
   ```

2. Copy `index.js` and `package.json` to the directory

3. Install dependencies:
   ```bash
   npm install
   ```

4. Configure Claude Desktop (`claude_desktop_config.json`):
   ```json
   {
     "mcpServers": {
       "mindmeld": {
         "command": "node",
         "args": ["/path/to/mindmeld-mcp/index.js"]
       }
     }
   }
   ```

5. Restart Claude Desktop

## Available Tools

- `create_mindmap(title)` - Create a new mind map
- `open_mindmap(file_path)` - Open a .mm file
- `get_structure()` - Get current structure as JSON
- `create_node(parent_id, text, position)` - Add a child node
- `update_node(node_id, text, color)` - Update node properties
- `delete_node(node_id)` - Delete a node and children
- `save_mindmap(file_path)` - Save to .mm file
- `export_mindmap(format)` - Export as JSON or Markdown

## Usage Examples

```
mindmeld:create_mindmap("Project Plan")
mindmeld:create_node("root", "Phase 1", "right")
mindmeld:export_mindmap("markdown")
mindmeld:save_mindmap("./my_plan.mm")
```

## Key Code Changes

### Parser Configuration (Line 38-45)
```javascript
const parserOptions = {
  ignoreAttributes: false,
  attributeNamePrefix: "", // Removes @_ prefix!
  allowBooleanAttributes: true,
  parseAttributeValue: false,
  trimValues: true,
};
```

### Path Normalization (Line 59-69)
```javascript
function normalizePath(inputPath) {
  if (!inputPath) return inputPath;
  if (path.isAbsolute(inputPath)) {
    return path.normalize(inputPath);
  }
  return path.resolve(process.cwd(), inputPath);
}
```

### Attribute Normalization (Line 114-132)
```javascript
function normalizeNodeAttributes(node) {
  // Handle potential @_ prefixed attributes
  const attrMappings = ['TEXT', 'ID', 'POSITION', ...];
  for (const attr of attrMappings) {
    if (node[`@_${attr}`] !== undefined && node[attr] === undefined) {
      node[attr] = node[`@_${attr}`];
      delete node[`@_${attr}`];
    }
  }
  // Recursively process children
}
```

## Testing

After installation, test with:

1. Create a test .mm file:
   ```xml
   <map version="1.0.1">
     <node TEXT="Test" ID="root">
       <node TEXT="Child" ID="child1"/>
     </node>
   </map>
   ```

2. Try opening it:
   ```
   mindmeld:open_mindmap("./test.mm")
   mindmeld:export_mindmap("markdown")
   ```

Should output:
```
- Test
  - Child
```
